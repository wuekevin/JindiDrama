# 短剧桌面客户端 · 独立开发起步版

参考 `yangbin1322/hongguo-player` 的**公开功能描述和产品交互方向**独立实现的 Go + Wails v2 + Vue 3 桌面端示例；**未复制其私有源码，不使用其品牌资源**。

## 当前已实现

- Windows/macOS 桌面端骨架、深色 UI、推荐与分类、搜索、详情/分集、播放器区域、弹幕/评论面板
- 通过 Wails JS Bindings 调用 Go：目录、搜索、分集、播放、弹幕、评论和账号状态（演示接口）
- 演示剧集数据（虚构，不对应任何版权视频）
- 收藏和观看进度通过 Go 写入系统用户配置目录下的 `shortplay-desktop/state.json`，原子落盘
- 适配层 `internal/provider/Provider`，便于接入**经授权**的内容、认证、视频、评论与弹幕 API

## 未实现（需要真实授权接口）

- 红果官方手机号登录、验证码、真实播放、评论写入、弹幕发送、云端片单与历史同步
- 视频 DRM 解密、设备伪装、反爬/签名绕过
- 高清解码增强、下载、热更新、自动化集成测试、签名发布

**本工程是功能性 UI + 本地数据 MVP，不是完整的红果联网客户端。** 登录/视频等 UI 均显示明确的未接入提示。

## 环境与运行

- Go 1.23+、Node.js 20+、Wails CLI v2
- Windows 需要 WebView2，macOS 需要 Xcode Command Line Tools

```bash
# 安装 Wails CLI（网络安装）
go install github.com/wailsapp/wails/v2/cmd/wails@latest
cd frontend
npm install
cd ..
wails dev
# 或生成安装前的桌面可执行文件
wails build
```

如果不安装 Wails 也可以先看 Vue UI：

```bash
cd frontend
npm install
npm run dev
```

单独预览网页时使用浏览器中的临时演示状态；运行 Wails 时通过 Go API 持久化本地收藏和历史。

## 集成接口规范

`internal/provider/provider.go` 中的 `Provider` 接口：

- `Catalog(ctx)` -> `[]Drama`
- `Search(ctx, keyword)` -> `[]Drama`
- `Episodes(ctx, dramaID)` -> `[]Episode`
- `Playback(ctx, episodeID)` -> `Playback{url,mime,authorized,notice}`
- `Danmaku(ctx, episodeID)` -> `[]Danmaku{offsetMs,text}`
- `Comments(ctx, dramaID)` -> `[]Comment`

可新建 `internal/provider/authorized.go`，接入具有明确许可的上游 API，在 `NewApp` 中替换 `provider.NewDemo()`。必须在服务端确认媒体可播放权限，并确保视频资源本身具备播放授权。用户鉴权和云同步需设计明确的授权协议与安全凭据存储（OS Keychain/Windows Credential Manager），不应写入普通 JSON。

## 法律与工程边界

参考项目 `yangbin1322/hongguo-player` 的公开功能，不表示取得其私有源代码或红果品牌、影视资源、账号服务的许可。项目独立命名为“映界”仅供原型展示；正式上线应另行核实品牌和授权。不要把内网/移动 App 私有接口当成官方开放平台。
