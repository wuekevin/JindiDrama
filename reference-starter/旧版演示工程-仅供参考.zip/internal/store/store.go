package store

import (
	"encoding/json"
	"example.com/shortplay-desktop/internal/model"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type Store struct {
	mu    sync.Mutex
	path  string
	state model.State
}

func New(path string) (*Store, error) {
	s := &Store{path: path, state: model.State{Favorites: []model.Drama{}, History: []model.Progress{}}}
	b, err := os.ReadFile(path)
	if err == nil {
		if err = json.Unmarshal(b, &s.state); err != nil {
			return nil, err
		}
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	return s, nil
}
func (s *Store) Get() model.State { s.mu.Lock(); defer s.mu.Unlock(); return clone(s.state) }
func clone(st model.State) model.State {
	return model.State{Favorites: append([]model.Drama{}, st.Favorites...), History: append([]model.Progress{}, st.History...)}
}
func (s *Store) save() error {
	if err := os.MkdirAll(filepath.Dir(s.path), 0700); err != nil {
		return err
	}
	b, err := json.MarshalIndent(s.state, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err = os.WriteFile(tmp, b, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}
func (s *Store) ToggleFavorite(d model.Drama) (model.State, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	found := false
	out := make([]model.Drama, 0, len(s.state.Favorites)+1)
	for _, v := range s.state.Favorites {
		if v.ID == d.ID {
			found = true
		} else {
			out = append(out, v)
		}
	}
	if !found {
		out = append([]model.Drama{d}, out...)
	}
	previous := s.state
	s.state.Favorites = out
	if err := s.save(); err != nil {
		s.state = previous
		return clone(s.state), err
	}
	return clone(s.state), nil
}
func (s *Store) UpdateProgress(p model.Progress) (model.State, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	p.UpdatedAt = time.Now().Unix()
	out := []model.Progress{p}
	for _, v := range s.state.History {
		if v.DramaID != p.DramaID {
			out = append(out, v)
		}
	}
	previous := s.state
	s.state.History = out
	if err := s.save(); err != nil {
		s.state = previous
		return clone(s.state), err
	}
	return clone(s.state), nil
}
