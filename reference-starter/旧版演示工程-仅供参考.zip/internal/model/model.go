package model

type Drama struct {
	ID           string `json:"id"`
	Title        string `json:"title"`
	Description  string `json:"description"`
	Category     string `json:"category"`
	Cover        string `json:"cover"`
	EpisodeCount int    `json:"episodeCount"`
	Tag          string `json:"tag"`
}
type Episode struct {
	ID      string `json:"id"`
	DramaID string `json:"dramaId"`
	Index   int    `json:"index"`
	Title   string `json:"title"`
}
type Playback struct {
	URL        string `json:"url"`
	Mime       string `json:"mime"`
	Notice     string `json:"notice"`
	Authorized bool   `json:"authorized"`
}
type Danmaku struct {
	ID       string `json:"id"`
	OffsetMS int    `json:"offsetMs"`
	Text     string `json:"text"`
}
type Comment struct {
	ID     string `json:"id"`
	Author string `json:"author"`
	Text   string `json:"text"`
	Likes  int    `json:"likes"`
}
type Progress struct {
	DramaID      string  `json:"dramaId"`
	DramaTitle   string  `json:"dramaTitle"`
	EpisodeID    string  `json:"episodeId"`
	EpisodeIndex int     `json:"episodeIndex"`
	PositionSec  float64 `json:"positionSec"`
	UpdatedAt    int64   `json:"updatedAt"`
}
type State struct {
	Favorites []Drama    `json:"favorites"`
	History   []Progress `json:"history"`
}
type AccountStatus struct {
	Authenticated bool   `json:"authenticated"`
	Message       string `json:"message"`
}
