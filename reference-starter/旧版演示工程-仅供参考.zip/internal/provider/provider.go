package provider

import (
	"context"
	"errors"
	"example.com/shortplay-desktop/internal/model"
	"strings"
)

// Provider is the integration boundary for a properly authorized content provider.
// No private Hongguo API, emulated device, signing bypass, credential capture or DRM decryption is included.
type Provider interface {
	Catalog(context.Context) ([]model.Drama, error)
	Search(context.Context, string) ([]model.Drama, error)
	Episodes(context.Context, string) ([]model.Episode, error)
	Playback(context.Context, string) (model.Playback, error)
	Danmaku(context.Context, string) ([]model.Danmaku, error)
	Comments(context.Context, string) ([]model.Comment, error)
}

type Demo struct{}

func NewDemo() *Demo { return &Demo{} }

var dramas = []model.Drama{
	{ID: "demo-1", Title: "雨夜来信", Description: "都市悬疑题材演示剧目，用于展示桌面播放界面。", Category: "都市", EpisodeCount: 12, Tag: "热播", Cover: ""},
	{ID: "demo-2", Title: "星河有约", Description: "浪漫题材演示条目，不对应任何真实视频资源。", Category: "爱情", EpisodeCount: 24, Tag: "上新", Cover: ""},
	{ID: "demo-3", Title: "长街旧梦", Description: "古风题材演示条目。", Category: "古装", EpisodeCount: 36, Tag: "精选", Cover: ""},
	{ID: "demo-4", Title: "此刻启程", Description: "成长题材演示条目。", Category: "励志", EpisodeCount: 18, Tag: "推荐", Cover: ""},
	{ID: "demo-5", Title: "迷雾之城", Description: "悬疑题材演示条目。", Category: "悬疑", EpisodeCount: 30, Tag: "完结", Cover: ""},
	{ID: "demo-6", Title: "有风的地方", Description: "生活题材演示条目。", Category: "生活", EpisodeCount: 20, Tag: "精选", Cover: ""},
}

func (d *Demo) Catalog(_ context.Context) ([]model.Drama, error) {
	return append([]model.Drama(nil), dramas...), nil
}
func (d *Demo) Search(_ context.Context, q string) ([]model.Drama, error) {
	if q == "" {
		return d.Catalog(context.Background())
	}
	out := []model.Drama{}
	for _, v := range dramas {
		if strings.Contains(strings.ToLower(v.Title+v.Description+v.Category), strings.ToLower(q)) {
			out = append(out, v)
		}
	}
	return out, nil
}
func (d *Demo) Episodes(_ context.Context, id string) ([]model.Episode, error) {
	for _, v := range dramas {
		if v.ID == id {
			list := make([]model.Episode, 0, v.EpisodeCount)
			for i := 1; i <= v.EpisodeCount; i++ {
				list = append(list, model.Episode{ID: id + "-ep-" + itoa(i), DramaID: id, Index: i, Title: "第 " + itoa(i) + " 集"})
			}
			return list, nil
		}
	}
	return nil, errors.New("drama not found")
}
func itoa(i int) string {
	if i < 10 {
		return string(rune('0' + i))
	}
	return intToString(i)
}
func intToString(i int) string {
	var buf [20]byte
	k := len(buf)
	for i > 0 {
		k--
		buf[k] = byte('0' + i%10)
		i /= 10
	}
	return string(buf[k:])
}
func (d *Demo) Playback(_ context.Context, _ string) (model.Playback, error) {
	return model.Playback{Authorized: false, Notice: "演示模式没有授权的视频源。请实现 Provider.Playback 并接入获授权的播放服务。"}, nil
}
func (d *Demo) Danmaku(_ context.Context, _ string) ([]model.Danmaku, error) {
	return []model.Danmaku{}, nil
}
func (d *Demo) Comments(_ context.Context, _ string) ([]model.Comment, error) {
	return []model.Comment{}, nil
}
