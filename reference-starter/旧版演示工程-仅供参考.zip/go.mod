module example.com/shortplay-desktop

go 1.23

require github.com/wailsapp/wails/v2 v2.10.2
