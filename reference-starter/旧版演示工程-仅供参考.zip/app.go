package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"example.com/shortplay-desktop/internal/model"
	"example.com/shortplay-desktop/internal/provider"
	"example.com/shortplay-desktop/internal/store"
)

type App struct {
	ctx context.Context
	p   provider.Provider
	s   *store.Store
}

func NewApp() *App { return &App{p: provider.NewDemo()} }

func (a *App) startup(ctx context.Context) {
	a.ctx = ctx
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = os.TempDir()
	}
	a.s, err = store.New(filepath.Join(dir, "shortplay-desktop", "state.json"))
	if err != nil {
		fmt.Println("Storage initialization failed:", err)
	}
}

func (a *App) GetCatalog() ([]model.Drama, error) { return a.p.Catalog(a.ctx) }
func (a *App) Search(query string) ([]model.Drama, error) {
	return a.p.Search(a.ctx, strings.TrimSpace(query))
}
func (a *App) GetEpisodes(id string) ([]model.Episode, error) { return a.p.Episodes(a.ctx, id) }
func (a *App) GetPlayback(episodeID string) (model.Playback, error) {
	return a.p.Playback(a.ctx, episodeID)
}
func (a *App) GetDanmaku(episodeID string) ([]model.Danmaku, error) {
	return a.p.Danmaku(a.ctx, episodeID)
}
func (a *App) GetComments(dramaID string) ([]model.Comment, error) {
	return a.p.Comments(a.ctx, dramaID)
}
func (a *App) GetAccountStatus() model.AccountStatus {
	return model.AccountStatus{Authenticated: false, Message: "未接入官方授权登录；演示模式不采集账号信息"}
}
func (a *App) GetState() model.State {
	if a.s == nil {
		return model.State{}
	}
	return a.s.Get()
}
func (a *App) ToggleFavorite(d model.Drama) (model.State, error) {
	if a.s == nil {
		return model.State{}, fmt.Errorf("local storage not available")
	}
	return a.s.ToggleFavorite(d)
}
func (a *App) UpdateProgress(entry model.Progress) (model.State, error) {
	if a.s == nil {
		return model.State{}, fmt.Errorf("local storage not available")
	}
	return a.s.UpdateProgress(entry)
}
