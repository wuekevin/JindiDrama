const demo=[
{id:'demo-1',title:'雨夜来信',category:'都市',tag:'热播',episodeCount:12,description:'都市悬疑题材演示剧目，用于展示桌面播放界面。'},
{id:'demo-2',title:'星河有约',category:'爱情',tag:'上新',episodeCount:24,description:'浪漫题材演示条目。'},
{id:'demo-3',title:'长街旧梦',category:'古装',tag:'精选',episodeCount:36,description:'古风题材演示条目。'},
{id:'demo-4',title:'此刻启程',category:'励志',tag:'推荐',episodeCount:18,description:'成长题材演示条目。'},
{id:'demo-5',title:'迷雾之城',category:'悬疑',tag:'完结',episodeCount:30,description:'悬疑题材演示条目。'},
{id:'demo-6',title:'有风的地方',category:'生活',tag:'精选',episodeCount:20,description:'生活题材演示条目。'}];
const native=()=>window.go?.main?.App;
const state={favorites:[],history:[]};
export const api={
 catalog:async()=>native()?native().GetCatalog():demo,
 search:async(q)=>native()?native().Search(q):demo.filter(x=>(x.title+x.description+x.category).includes(q)),
 episodes:async(id)=>native()?native().GetEpisodes(id):Array.from({length:demo.find(d=>d.id===id)?.episodeCount||0},(_,i)=>({id:`${id}-ep-${i+1}`,dramaId:id,index:i+1,title:`第 ${i+1} 集`})),
 playback:async(id)=>native()?native().GetPlayback(id):{authorized:false,url:'',notice:'演示模式没有授权的视频资源。'},
 danmaku:async(id)=>native()?native().GetDanmaku(id):[],
 comments:async(id)=>native()?native().GetComments(id):[],
 account:async()=>native()?native().GetAccountStatus():{authenticated:false,message:'未接入官方授权登录'},
 state:async()=>native()?native().GetState():structuredClone(state),
 favorite:async(d)=>{if(native())return native().ToggleFavorite(d);const i=state.favorites.findIndex(x=>x.id===d.id);i>=0?state.favorites.splice(i,1):state.favorites.unshift(d);return structuredClone(state)},
 progress:async(p)=>{if(native())return native().UpdateProgress(p);state.history=state.history.filter(x=>x.dramaId!==p.dramaId);state.history.unshift({...p,updatedAt:Date.now()/1000});return structuredClone(state)}
};
